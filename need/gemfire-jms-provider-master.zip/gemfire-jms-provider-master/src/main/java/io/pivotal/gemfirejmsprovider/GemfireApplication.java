package io.pivotal.gemfirejmsprovider;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GemfireApplication {

    public static void main(String[] args) {
        SpringApplication.run(GemfireApplication.class, args);
    }
}
